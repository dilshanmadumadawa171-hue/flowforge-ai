Connect the existing FlowForge Studio V2 UI to this backend.

POST:
http://localhost:3000/api/generate

Body:
{
  "prompt": "...",
  "duration": 10,
  "aspectRatio": "9:16"
}

Then poll:
GET http://localhost:3000/api/generate/:jobId
