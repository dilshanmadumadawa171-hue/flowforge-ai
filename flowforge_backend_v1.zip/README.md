# FlowForge Backend V1

A safe starter backend for the FlowForge AI video studio.

## Requirements
- Node.js 18+
- npm

## Run
```bash
cd backend
npm install
npm run dev
```

Open http://localhost:3000/health

The `/api/generate` endpoint is currently in TEST MODE. It creates a fake generation job and simulates completion, so no AI API key is required yet.

## Later
Set the real provider credentials in `.env` on the server. Never put API keys in browser/frontend code or commit `.env`.
